"""Launch the root jupyter command"""
if __name__ == "__main__":
    from jupyter_core.command import main

    main()
